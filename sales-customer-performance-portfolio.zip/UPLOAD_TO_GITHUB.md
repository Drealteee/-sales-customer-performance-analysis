# Upload to GitHub

1. Sign in to GitHub and create a new public repository.
2. Recommended repository name: `sales-customer-performance-analysis`
3. Add the contents of this folder:
   - README.md
   - sales-customer-performance-data-model.xlsx
   - data/
4. Commit with: `Add Excel sales and customer performance portfolio project`
5. Use the repository URL as your job-application work-sample link.

Before submitting, open the workbook and make sure you can explain:
- why Orders is the transaction/fact table;
- why Customers and Products are dimension tables;
- how Customer_ID and Product_ID connect the datasets;
- how Net Sales, Profit and Margin are calculated;
- how the dashboard summaries are produced.
