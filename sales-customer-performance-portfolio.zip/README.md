# Sales & Customer Performance Analysis

An original Excel portfolio project demonstrating practical **data modeling, spreadsheet analysis, KPI reporting, and dashboard design**.

## Project Overview
This project analyzes 500 synthetic sales transactions using a simple relational model built from three core datasets: Orders, Customers, and Products.

## Skills Demonstrated
- Relational data modeling using fact and dimension-style tables
- Excel Tables and structured data organization
- INDEX/MATCH lookups across datasets
- Formula-driven revenue, cost, profit, and margin calculations
- SUMIF-based KPI aggregation
- Error handling with IFERROR
- Business performance analysis by region and product category
- Dashboard design and chart-based reporting

## Workbook Structure
| Sheet | Purpose |
|---|---|
| Raw_Orders | Transaction-level source data |
| Customers | Customer dimension: segment and region |
| Products | Product dimension: category, price and cost |
| Model | Joined analytical model and calculated metrics |
| Dashboard | KPI summary and visual business insights |
| Project_Guide | Documentation inside the workbook |

## Key Metrics
The dashboard calculates total net sales, total profit, profit margin, order count, and average order value. It also compares sales and profit across regions and product categories.

## Data Model
`Raw_Orders` acts as the transaction/fact table. `Customers` and `Products` act as dimension tables. The `Model` sheet connects them through Customer_ID and Product_ID and calculates business metrics used by the dashboard.

## Files
- `sales-customer-performance-data-model.xlsx` — complete Excel analysis
- `data/raw_orders.csv` — source transaction data
- `data/customers.csv` — customer dimension
- `data/products.csv` — product dimension

## Note
All data is synthetic and was created specifically for this portfolio project. It does not contain confidential company or customer information.
